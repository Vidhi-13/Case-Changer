Write a program that calculates area of a triangle, given its 3 points (A, B and C) in the Descartes coordinate system.

- Input:

Point A (x, y): 10 20

Point B (x, y): 10 60

Point C (x, y): 80 20

-Output:

Area = 2400



