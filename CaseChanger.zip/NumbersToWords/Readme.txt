Develop a program that is able to read an arbitrary integer number from the command line, then prints out that number in words. 

For example:

-Input: 20
Output: twenty

- Input: 96
Output: eighty six

-Input: 365
Output: three hundred and sixty five


The program can read numbers up to 9999. Design this program in a way that can be re-used in other projects.