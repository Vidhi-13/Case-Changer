import java.util.Scanner;
public class Main 
{
    public static void main(String args[]) 
    {
      Scanner in = new Scanner(System.in);    
      System.out.println("Enter the amount you earn this month: ");
      int a = in.nextInt();
      System.out.println(a);
      double p = 0.55;
      p = p*a;
      double q = 0.1;
      q = q*a;
      double r = 0.1;
      r = r*a;
      double s = 0.1;
      s = s*a;
      double t = 0.1;
      t = t*a;
      double u = 0.05;
      u = u*a;
      System.out.println("NEC: "+(int)p);
      System.out.println("FFA: "+(int)q);
      System.out.println("EDU: "+(int)r);
      System.out.println("LTSS: "+(int)s);
      System.out.println("PLAY: "+(int)t);
      System.out.println("GIVE: "+(int)u);
    }
}






