Write a program that prints the Fibonacci sequence numbers less than a given number N. For example:

- Input: N = 10                 Output: 1 2 3 5 8

-Input: - 30                    Output: 3 5 8 13 21

-Input: N = 60                  Output: 1 1 2 3 5 8 13 21 34 55



